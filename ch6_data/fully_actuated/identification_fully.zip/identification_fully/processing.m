clear all;
%clc;
d=1;
t=5;
ts=2e-3;
qd=[0.6 0.8]
suf='ta'
n=1

%50%percent and 75%
ktg1=1;
ktg2=0.6;
ki=[30/ktg1^2 10/ktg2^2]

for i=n:n+4
    if i==n
        [Psit,Phit]=regressor(i,ki,d,t,ts,qd,suf);
        Psi=[Psit];
        Phi=[Phit];
    else
        [Psit,Phit]=regressor(i,ki,d,t,ts,qd,suf);
        Psi=[Psi;Psit];
        Phi=[Phi;Phit];
    end
    
    
end




gamma=(Psi'*Psi)\Psi'*Phi
norm(Psi*gamma-Phi)

% 
fun=@(gamma)sum((Psi*gamma-Phi).^2);
gamma = fmincon(fun,[0;0],[],[],[],[],[0;0],[inf;inf])
sum((Psi*gamma-Phi).^2)