function [Psi,Phi]=regressor(n,ki,d,t,ts,qd,suf)

%n:number of file. Eg, if data3.mat, set 3
%d: 1 for diagonal case and 0 for symetric general
%t: acquired time data
%ts: sampling time
%qd: desired position
%ki: integral control gains

%For rigid link planar PI stabilized


%File loading
filename=[suf num2str(n,'%d') '.mat'];
load(filename);
q1=data_ql.signals.values(:,1);
q2=data_ql.signals.values(:,2);
qdot1=data_qdotl.signals.values(:,1);
qdot2=data_qdotl.signals.values(:,2);
qddot1=data_qddotl.signals.values(:,1);
qddot2=data_qddotl.signals.values(:,2);
dt=0:ts:t;
qd1=qd(1);
qd2=qd(2);

%Mass Inertial matrix
m1=1.5;
m2=0.8733;
I1=0.0102;
I2=0.0085;
r1=0.159;
r2=0.0550; 
l1=0.3493;
l2=0.2975;
a1=m1*r1^2+m2*l1^2+I1;
a2=m2*r2^2+I2;
b=m2*l1*r2;



for i=1:size(q2)
dMdq2=[-2*b*sin(q2(i)), -b*sin(q2(i));  -b*sin(q2(i)), 0];
j(i)=0.5*qdot2(i)*[qdot1(i) qdot2(i)]*dMdq2*[qdot1(i) ;qdot2(i)];
m11(i)=a1+a2+2*b*cos(q2(i));
m12(i)=a2+b*cos(q2(i));
m22(i)=a2;
m11dot(i)=-2*b*sin(q2(i))*qdot2(i);
m12dot(i)=-b*sin(q2(i))*qdot2(i);
end

m11=m11';
m22=m22';
m12=m12';
m11dot=m11dot';
m12dot=m12dot';
j=j';

Phi1= trapz(dt,qdot1.*(m11dot.*qdot1+m12dot.*qdot2))+trapz(dt,qdot1.*(m11.*qddot1+m12.*qddot2))+trapz(dt,ki(1)*(q1-qd1).*qdot1);
Phi2= -trapz(dt,j)+trapz(dt,ki(2)*(q2-qd2).*qdot2)+trapz(dt,qdot2.*(m12dot.*qdot1))+trapz(dt,qdot2.*(m12.*qddot1+m22.*qddot2));

Phi=[Phi1;Phi2];

if d==1
    Psi=-diag([trapz(dt,qdot1.^2), trapz(dt,qdot2.^2)]);%diagonal case
else
    Psi=-[trapz(dt,qdot1.^2) trapz(dt,qdot1.*qdot2) 0; 0 trapz(dt,qdot1.*qdot2) trapz(dt,qdot2.^2)];
end
%gamma=(Psi'*Psi)\Psi'*Phi ;

end
