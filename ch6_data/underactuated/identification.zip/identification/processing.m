clear all;
clc;
d=1;
t=10; %simulation time
ts=2e-3;
qd=[0.6 0.8];

ktg1=1;
ktg2=0.600;
%ktg2=1;
ki=[30/ktg1^2 10/ktg2^2]

suffix='data\sub';
n=1;


for i=n:n+4
    if i==n
        [Psit,Phit]=regressorUnd(i,ki,d,t,ts,qd,suffix);
        Psi=[Psit];
        Phi=[Phit];
    else
        [Psit,Phit]=regressorUnd(i,ki,d,t,ts,qd,suffix);
        Psi=[Psi;Psit];
        Phi=[Phi;Phit];
    end    
    
end
gamma=(Psi'*Psi)\Psi'*Phi
sum((Psi*gamma-Phi).^2)

fun=@(gamma)sum((Psi*gamma-Phi).^2);
gamma = fmincon(fun,[10;10;10;10],[],[],[],[],[0;0;0;0],[inf;inf;inf;inf])
sum((Psi*gamma-Phi).^2)
% 
