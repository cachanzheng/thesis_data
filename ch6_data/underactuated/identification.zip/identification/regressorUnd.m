function [Psi,Phi]=regressorUnd(n,ki,d,t,ts,qd,suf)
%n:number of file. Eg, if data3.mat, set 3
%d: 1 for diagonal case and 0 for symetric general
%t: acquired time data
%ts: sampling time
%qd: desired position
%For flexible link planar stabilized with PI


%File loading
filename=[suf num2str(n,'%d') '.mat'];
n=1;
load(filename);
q1=data_ql.signals.values(:,1);
q2=data_ql.signals.values(:,2);
q3=data_qm.signals.values(:,1);
q4=data_qm.signals.values(:,2);
qdot1=data_qdotl.signals.values(:,1);
qdot2=data_qdotl.signals.values(:,2);
qdot3=data_qdotm.signals.values(:,1);
qdot4=data_qdotm.signals.values(:,2);
qddot1=data_qddotl.signals.values(:,1);
qddot2=data_qddotl.signals.values(:,2);
qddot3=data_qddotm.signals.values(:,1);
qddot4=data_qddotm.signals.values(:,2);


% Sim data - uncomment for sim data
%load('sim_data.mat')
% q1=out.q.Data(:,1);
% q2=out.q.Data(:,2);
% q3=out.q.Data(:,3);
% q4=out.q.Data(:,4);
% qdot1=out.qdot.Data(:,1);
% qdot2=out.qdot.Data(:,2);
% qdot3=out.qdot.Data(:,3);
% qdot4=out.qdot.Data(:,4);
% qddot1=out.qddot.Data(:,1);
% qddot2=out.qddot.Data(:,2);
% qddot3=out.qddot.Data(:,3);
% qddot4=out.qddot.Data(:,4);
dt=0:ts:t;
qd1=qd(1);
qd2=qd(2);

% 


%Spring Constant
%ks=[6.74,4.2144]; %diagonal
ks=[8.43, 16.86];
%ks=[9 4];
%Mass Inertial matrix
m1=1.5;
m2=0.8733;
I1=0.0102;
I2=0.0085;
r1=0.159;
r2=0.0550; 
l1=0.3493;
l2=0.2975;
a1=m1*r1^2+m2*l1^2+I1;
a2=m2*r2^2+I2;
b=m2*l1*r2;

% b=theta2;
% a2=theta3;
% a1=theta1-a2;
for i=1:size(q2)
dMdq2=[-2*b*sin(q2(i)), -b*sin(q2(i));  -b*sin(q2(i)), 0];
j(i)=0.5*qdot2(i)*[qdot1(i) qdot2(i)]*dMdq2*[qdot1(i) ;qdot2(i)];
m11(i)=a1+a2+2*b*cos(q2(i));
m12(i)=a2+b*cos(q2(i));
m22(i)=a2;
m11dot(i)=-2*b*sin(q2(i))*qdot2(i);
m12dot(i)=-b*sin(q2(i))*qdot2(i);
end

m11=m11';
m22=m22';
m12=m12';
m11dot=m11dot';
m12dot=m12dot';
j=j';

%Mass Inertial values for Motor
Im1=0.0628; %m33
 Im2=0.0026; %m44

W1= qdot1.*(m11dot.*qdot1+m12dot.*qdot2)+qdot1.*(m11.*qddot1+m12.*qddot2);
W2= -j+qdot2.*(m12dot.*qdot1)+qdot2.*(m12.*qddot1+m22.*qddot2);
W3= (Im1.*qdot3).*qddot3;
W4= (Im2.*qdot4).*qddot4+(0.5/0.6^2).*qdot4; %%Watch out here since I am adding a extra KP in this test

P1=ks(1)*qdot1.*(q1-q3);
P2=ks(2)*qdot2.*(q2-q4);
P3=qdot3.*(-ks(1)*(q1-q3)+ki(1)*(q3-qd1));
P4=qdot4.*(-ks(2)*(q2-q4)+ki(2)*(q4-qd2));

[trapz(dt,W1);trapz(dt,W2);trapz(dt,W3);trapz(dt,W4)]
[trapz(dt,P1);trapz(dt,P2);trapz(dt,P3);trapz(dt,P4)];


Phi1=trapz(dt,W1)+trapz(dt,P1);
Phi2=trapz(dt,W2)+trapz(dt,P2);
Phi3=trapz(dt,W3)+trapz(dt,P3);
Phi4=trapz(dt,W4)+trapz(dt,P4);



Phi=[Phi1;Phi2;Phi3;Phi4];
if d==1
    Psi=-diag([trapz(dt,qdot1.^2), trapz(dt,qdot2.^2),trapz(dt,qdot3.^2), trapz(dt,qdot4.^2)]);%diagonal case
else
    Psi=-[trapz(dt,qdot1.^2) trapz(dt,qdot1.*qdot2) trapz(dt,qdot1.*qdot3) trapz(dt,qdot1.*qdot4) 0 0 0 0 0 0;
        0 trapz(dt,qdot1.*qdot2) 0 0 trapz(dt,qdot2.^2) trapz(dt,qdot2.*qdot3) trapz(dt,qdot2.*qdot4) 0 0 0;
        0 0 trapz(dt,qdot1.*qdot3) 0 0 trapz(dt,qdot2.*qdot3) 0 trapz(dt,qdot3.^2) trapz(dt,qdot3.*qdot4) 0;
        0 0 0 trapz(dt,qdot1.*qdot4) 0 0 trapz(dt,qdot2.*qdot4) 0 trapz(dt,qdot3.*qdot4) trapz(dt,qdot4.^2)];
end


end
